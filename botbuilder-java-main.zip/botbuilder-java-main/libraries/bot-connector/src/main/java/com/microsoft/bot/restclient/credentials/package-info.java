// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

/**
 * The package provides 2 basic credential classes that work with AutoRest
 * generated clients for authentication purposes.
 */
package com.microsoft.bot.restclient.credentials;
