// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

/**
 * The package contains classes that interfaces defining the behaviors
 * of the necessary components of a Rest Client.
 */
package com.microsoft.bot.restclient.protocol;
